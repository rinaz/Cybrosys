OHRMS Disciplinary Action v14
==============================

Track the Disciplinary actions of Employees

Depends
=======
[oh_employee_creation_from_user] addon Open HRMS
[mail] addon Odoo

Tech
====
* [Python] - Models
* [XML] - Odoo views

Installation
============
- www.odoo.com/documentation/14.0/setup/install.html
- Install our custom addon


Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Credits
=======
* Cybrosys Techno Solutions <https://www.cybrosys.com>

Author
------

Developer: Ajmal J K @ cybrosys
          Version 14: Muhammed Nafih @cybrosys

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
