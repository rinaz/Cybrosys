## Module <hrms_dashboard>

#### 05.10.2020
#### Version 14.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project


#### 11.23.2020
#### Version 14.0.1.0.1
##### FIX
- Employee can access all info. in dashboard - fixed.