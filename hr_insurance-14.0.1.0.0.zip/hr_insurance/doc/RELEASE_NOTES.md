## Module <hr_insurance>

#### 05.04.2019
#### Version 14.0.1.0.0
##### ADD
- Initial commit for OpenHrms Project
