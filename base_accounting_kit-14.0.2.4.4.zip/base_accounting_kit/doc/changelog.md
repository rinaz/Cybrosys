## Module <base_accounting_kit>

#### 03.10.2020
#### Version 14.0.1.0.0
#### ADD
- Initial commit for Odoo 14 accounting

#### 13.10.2020
#### Version 14.0.1.1.1
#### UPDT
- Trial Balane missing issue updated

#### 18.10.2020
#### Version 14.0.1.2.2
#### UPDT
- Added action in dashboard

#### 18.11.2020
#### Version 14.0.1.3.3
#### UPDT
- Field parameter spelling mistake updated.

#### 05.01.2021
#### Version 14.0.1.4.4
#### UPDT
- Removed warnings, Updated access rules.

#### 18.01.2021
#### Version 14.0.2.4.4
#### UPDT
- Reconciliation Widget Added.


