## Module <hr_multi_company>

#### 05.10.2020
#### Version 14.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
