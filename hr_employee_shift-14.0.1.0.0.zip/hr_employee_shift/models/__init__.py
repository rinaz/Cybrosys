# -*- coding: utf-8 -*-

from . import hr_employee_shift, hr_employee_contract, hr_generate_shift, hr_shift_payroll
# from . import resource
