# -*- coding: utf-8 -*-
from . import res_partner_agency
from . import employee_verification
